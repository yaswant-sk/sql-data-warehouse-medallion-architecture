#' Run a pipeline under observability.
#'
#' Wrap the whole script body in pw_run(). It creates one run_id and timestamp,
#' records who ran it, times the run, catches errors, logs success/failure,
#' and alerts on any failure or blocked write.
#'
#' @param pipeline  name of the pipeline, e.g. "orders_pipeline"
#' @param con       DBI connection to the Postgres database holding pipeline_observability
#' @param code      the pipeline body, usually wrapped in { }
#' @param override  TRUE to let a run through despite failed checks (logged with your username)
pw_run <- function(pipeline, con, code, override = FALSE) {
  ctx <- new.env(parent = emptyenv())
  ctx$pipeline <- pipeline
  ctx$con      <- con
  ctx$run_id   <- UUIDgenerate()
  ctx$run_ts   <- Sys.time()
  ctx$run_by   <- Sys.info()[["user"]]
  ctx$override <- override
  ctx$sources  <- list()          # input metrics per source, used for reconciliation

  .pw$ctx <- ctx
  on.exit(.pw$ctx <- NULL, add = TRUE)

  err <- tryCatch({ code; NULL }, error = function(e) e)

  # Operational metrics: run time, success/failure, error message
  secs <- as.numeric(difftime(Sys.time(), ctx$run_ts, units = "secs"))
  ops <- bind_rows(
    metric("run_duration_sec", secs),
    metric("pipeline_success", is.null(err), baseline = 1,
           status = if (is.null(err)) "ok" else "fail",
           notes = if (!is.null(err)) list(error = conditionMessage(err)))
  )
  try(log_metrics(con, ops, ctx$run_id, pipeline, "ops", NA_character_,
                  ctx$run_ts, ctx$run_by), silent = TRUE)

  if (!is.null(err)) {
    blocked <- startsWith(conditionMessage(err), "BLOCKED")
    pw_notify(ctx, if (blocked) "blocked" else "failed",
              if (blocked) "Pipeline blocked by data checks" else "Pipeline failed",
              conditionMessage(err))
    stop(err)
  }
  invisible(TRUE)
}

#' Profile a SOURCE table before using it. Logs the profile, compares it with
#' earlier runs, and stops the pipeline if a check fails.
#'
#' @param from          table ("raw.orders") or aliased subquery ("(SELECT ...) t")
#' @param key           ONE column that should be unique
#' @param ts_col        "last updated" timestamp column
#' @param numeric_cols  columns to track mean/sum for
#' @param rules         named SQL conditions that must be TRUE, e.g. c(amount_ok = "amount >= 0")
#' @param name          label used in the log (defaults to `from`; set it for subqueries)
pw_source <- function(from, key, ts_col, numeric_cols = NULL, rules = NULL, name = from) {
  ctx <- current_ctx()
  p <- profile_sql(ctx$con, from, key, ts_col, numeric_cols, rules)
  m <- run_profile_checks(ctx$con, p, ctx$pipeline, name, "input", pw_cfg())
  m <- bind_rows(m, metric("lineage_source", NA_real_, notes = list(source = name)))

  d <- decide_gate(ctx, m, name, "input")
  log_metrics(ctx$con, d$m, ctx$run_id, ctx$pipeline, "input", name, ctx$run_ts, ctx$run_by)
  ctx$sources[[name]] <- d$m

  if (d$block) stop(block_message(name, "input", d$fails), call. = FALSE)
  invisible(d$m)
}

#' Write a result to a TARGET table safely.
#' Writes inside a transaction, profiles the table, runs the checks, and rolls the
#' write back if anything fails. Log rows are written after the transaction ends.
#'
#' @param df         data frame to write
#' @param table      target table, e.g. "mart.orders"
#' @param mode       "truncate" (empty table, keep its structure; default), "append", or
#'                   "overwrite" (drop and recreate, loses indexes and grants)
#' @param reconcile  list(source = "raw.orders", metrics = "sum_amount") to check that totals match
pw_write <- function(df, table, key, ts_col, numeric_cols = NULL, rules = NULL,
                     reconcile = NULL, mode = c("truncate", "append", "overwrite")) {
  mode <- match.arg(mode)
  ctx  <- current_ctx()
  con  <- ctx$con
  id   <- as_id(table)
  from <- as.character(dbQuoteIdentifier(con, id))
  m_out <- NULL
  err   <- NULL

  ok <- tryCatch({
    dbWithTransaction(con, {
      if (mode == "truncate") {
        dbExecute(con, paste("TRUNCATE", from))
        dbAppendTable(con, id, df)
      } else {
        dbWriteTable(con, id, df, overwrite = (mode == "overwrite"), append = (mode == "append"))
      }

      p     <- profile_sql(con, from, key, ts_col, numeric_cols, rules)
      m_out <- run_profile_checks(con, p, ctx$pipeline, table, "output", pw_cfg())

      if (!is.null(reconcile)) {
        src <- ctx$sources[[reconcile$source]]
        if (is.null(src)) stop("Unknown source for reconciliation: ", reconcile$source, call. = FALSE)
        for (nm in reconcile$metrics) m_out <- bind_rows(m_out, reconcile_metric(src, m_out, nm))
      }
      m_out <- bind_rows(m_out, lineage_metric(names(ctx$sources), table))

      d     <- decide_gate(ctx, m_out, table, "output")
      m_out <- d$m
      if (d$block) stop(block_message(table, "output", d$fails), call. = FALSE)
    })
    TRUE
  }, error = function(e) { err <<- e; FALSE })

  if (!is.null(m_out))
    log_metrics(con, m_out, ctx$run_id, ctx$pipeline, "output", table, ctx$run_ts, ctx$run_by)
  if (!ok) stop(err)
  invisible(m_out)
}
