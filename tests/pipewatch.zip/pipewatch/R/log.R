# Insert metric rows into the central table. Explicit casts for uuid/timestamptz/jsonb.
log_metrics <- function(con, metrics, run_id, pipeline, stage, table_name = NA_character_,
                        run_ts = Sys.time(), run_by = Sys.info()[["user"]]) {
  m <- metrics %>%
    mutate(run_id = run_id, pipeline_name = pipeline, run_timestamp = run_ts,
           run_by = run_by, stage = stage, table_name = table_name)

  dbExecute(con, "
    INSERT INTO pipeline_observability
      (run_id, pipeline_name, run_timestamp, run_by, stage, table_name,
       metric_name, metric_value, baseline_value, status, notes)
    VALUES ($1::uuid, $2, $3::timestamptz, $4, $5, $6, $7, $8, $9, $10, $11::jsonb)",
    params = unname(as.list(m[c("run_id", "pipeline_name", "run_timestamp", "run_by",
                                "stage", "table_name", "metric_name", "metric_value",
                                "baseline_value", "status", "notes")])))
  invisible(metrics)
}

# How many earlier runs exist for this pipeline/table/stage? (for learning mode)
count_prior_runs <- function(con, pipeline, table_name, stage) {
  as.numeric(dbGetQuery(con, "
    SELECT count(DISTINCT run_id) AS n FROM pipeline_observability
    WHERE pipeline_name = $1 AND table_name = $2 AND stage = $3",
    params = list(pipeline, table_name, stage))$n)
}

#' Create the log table, indexes and dashboard views (safe to run repeatedly)
pw_install_schema <- function(con) {
  path <- system.file("sql", "schema.sql", package = "pipewatch")
  if (path == "") path <- file.path("inst", "sql", "schema.sql")   # running from source
  sql <- paste(readLines(path), collapse = "\n")
  for (stmt in trimws(strsplit(sql, ";", fixed = TRUE)[[1]])) {
    if (nzchar(stmt)) dbExecute(con, stmt)
  }
  invisible(TRUE)
}
