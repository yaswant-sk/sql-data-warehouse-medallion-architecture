# pipewatch: observability and monitoring for R data pipelines

Profiles source and target tables in Postgres, compares every run with the
history stored in one central log table, blocks bad writes, and alerts the
person who ran the script.

## How it works

```
 script  ──pw_run()──────────────────────────────────────────────┐
   │  pw_source("raw.x")  → profile in SQL → compare → log → gate │
   │  ... your existing R code ...                                │
   │  pw_write(df,"mart.y") → transaction → profile → compare     │
   │                          → reconcile → gate (rollback on fail)│
   └─ ops metrics (duration, success, error) + alerts ────────────┘
                         │
              pipeline_observability  (one central table)
                         │
        views: v_pipeline_latest, v_failed_checks_7d  → dashboard
```

- **No old data is stored.** Each run's summary statistics are the baseline for the next run.
- **First runs learn.** The first 3 runs per table (`learning_runs`) are logged but never block.
- **Baseline = median of the last 10 runs** (`n_baseline`). Failed metrics are excluded, so a bad load cannot become the baseline.

## Five pillars: what is checked

| Pillar | Check (metric name) | Needs history? | Warn | Fail |
|---|---|---|---|---|
| Freshness | Hours since newest source timestamp (`freshness_hours`) | No | n/a | older than `max_age_hours` |
| Freshness | Newest timestamp advanced (`newest_ts_epoch`) | Yes | n/a | did not advance |
| Volume | Row count vs baseline (`row_count`) | Yes | ±30% | ±50% |
| Volume | Reconciliation, e.g. `sum_amount_reconciliation_diff` | No (input vs output of same run) | n/a | not equal |
| Distribution | Null rate per column (`null_rate_<col>`) | Yes | +5 points | +10 points |
| Distribution | Duplicate keys (`duplicate_keys`) | No | n/a | any |
| Distribution | Mean and sum of numeric columns (`mean_<col>`, `sum_<col>`) | Yes | ±30% | ±50% |
| Distribution | Business rules (`rule_<name>`) | No | n/a | any violation |
| Schema | Columns added, removed, retyped (`schema_changes`) | Yes | any change | n/a |
| Lineage | Sources and target (`lineage`, `lineage_source`), plus `run_id`, `run_by`, `pipeline_name` on every row | No | n/a | n/a |
| Operational | `run_duration_sec`, `pipeline_success`, error text in `notes` | No | n/a | run crashed |

Thresholds are starting points. Change them with `pw_config(warn_change = 0.2)`.

## Developer quick start

```r
library(pipewatch)

pw_run("orders_pipeline", con, {
  pw_source("raw.orders", key = "order_id", ts_col = "updated_at",
            numeric_cols = "amount", rules = c(amount_ok = "amount >= 0"))

  df <- dbGetQuery(con, "SELECT * FROM raw.orders")   # existing code
  df_result <- transform(df)                           # existing code

  pw_write(df_result, "mart.orders", key = "order_id", ts_col = "updated_at",
           numeric_cols = "amount",
           reconcile = list(source = "raw.orders", metrics = "sum_amount"))
})
```

Three things to remember: wrap in `pw_run()`, call `pw_source()` before using a
source, call `pw_write()` instead of `dbWriteTable()`. See
`inst/examples/orders_pipeline.R`.

For a query instead of a table, use an aliased subquery and a label:
`pw_source("(SELECT * FROM raw.orders WHERE region = 'EU') t", name = "raw.orders_eu", ...)`.

## When a check blocks your run

The script stops with `BLOCKED: ...` and names the failed checks. Nothing is
written (input checks stop before processing, output checks roll the write
back). If the change is legitimate (for example a real 50% drop), re-run with
`pw_run(..., override = TRUE)`. Overridden fails are logged as `warn` and tagged
with your username, so the baseline can move to the new level.

## Alerts

- Always printed to the console of whoever ran the script.
- Slack: set the `PIPEWATCH_SLACK_WEBHOOK` environment variable (needs `httr2`).
- Email or anything else: `options(pipewatch.alert_fn = function(msg, ctx) ...)`.
- Alerts fire on blocked runs and crashes, and name the pipeline, `run_by` and `run_id`.

## Setup (once)

1. `pw_install_schema(con)` creates `pipeline_observability`, indexes and views.
2. Install the package from your internal Git: `remotes::install_git("<repo url>")`.
3. Point your dashboard (Metabase, Grafana, Shiny) at `v_pipeline_latest` and `v_failed_checks_7d`.

## Rollout plan

1. **Pilot (1 to 2 weeks):** 2 or 3 pipelines, learning mode, review the first logged runs by hand.
2. **Roll out:** add the three lines to remaining pipelines, turn on Slack alerts.
3. **Harden:** add business rules per pipeline, tune thresholds from real history.
4. **Later:** downstream scripts check `v_pipeline_latest` before starting, column-level lineage, run-duration baselines.

## Known limits

- One key column per table in `pw_source()`/`pw_write()`.
- `pw_write()` writes the whole dataframe at once. For very large writes, write to a staging table first.
- Profiling runs full-table aggregates. On very large tables, point it at a partition or a recent slice with a subquery.
- Reconciliation assumes you did not deliberately drop or change rows.
- `mode = "overwrite"` drops and recreates the table (loses indexes and grants). Prefer the default `"truncate"`.
- Not yet tested against a live database. Run `devtools::test()` (grading logic, no database needed), then try one pipeline on a copy of the data.
