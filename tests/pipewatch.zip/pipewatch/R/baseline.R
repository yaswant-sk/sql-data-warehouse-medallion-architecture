# Median of the last n runs per metric from the central log table.
# newest_ts_epoch uses only the previous run ("did the data advance?").
# Runs where a metric FAILED are excluded, so a bad load cannot become the baseline.
get_baselines <- function(con, pipeline, table_name, stage, n) {
  dbGetQuery(con, "
    SELECT metric_name,
           percentile_cont(0.5) WITHIN GROUP (ORDER BY metric_value)::float8 AS baseline_value
    FROM (
      SELECT metric_name, metric_value,
             row_number() OVER (PARTITION BY metric_name ORDER BY run_timestamp DESC) AS rn
      FROM pipeline_observability
      WHERE pipeline_name = $1 AND table_name = $2 AND stage = $3
        AND status <> 'fail' AND metric_value IS NOT NULL
    ) t
    WHERE rn <= CASE WHEN metric_name = 'newest_ts_epoch' THEN 1 ELSE $4::int END
    GROUP BY metric_name",
    params = list(pipeline, table_name, stage, as.integer(n)))
}

# Grade today's metrics against the baselines
grade_against_baseline <- function(m, base, cfg) {
  m %>%
    left_join(base, by = "metric_name") %>%   # first run: baseline NA, nothing fails
    mutate(
      chg = abs(metric_value - baseline_value) / abs(baseline_value),
      status = case_when(
        # Freshness: data older than the agreed limit
        metric_name == "freshness_hours" ~
          if_else(metric_value > cfg$max_age_hours, "fail", "ok"),
        # Freshness: newest timestamp must move forward vs previous run
        metric_name == "newest_ts_epoch" ~
          if_else(!is.na(baseline_value) & metric_value <= baseline_value, "fail", "ok"),
        # Duplicates and business rules: any violation fails (no history needed)
        metric_name == "duplicate_keys" | startsWith(metric_name, "rule_") ~
          if_else(metric_value > 0, "fail", "ok"),
        # Null rates: absolute rise in points vs baseline
        startsWith(metric_name, "null_rate_") ~ case_when(
          is.na(baseline_value) ~ "ok",
          metric_value - baseline_value >= cfg$null_fail ~ "fail",
          metric_value - baseline_value >= cfg$null_warn ~ "warn",
          TRUE ~ "ok"),
        # Row count, means, sums: relative change vs baseline
        is.na(chg) ~ "ok",
        chg >= cfg$fail_change ~ "fail",
        chg >= cfg$warn_change ~ "warn",
        TRUE ~ "ok"),
      status = coalesce(status, "warn"),       # NULL stats never pass silently
      notes = NA_character_) %>%
    select(metric_name, metric_value, baseline_value, status, notes)
}

# Pillar 4 (schema): compare with the column list stored by the previous run
check_schema_snapshot <- function(con, pipeline, table_name, stage, schema) {
  snap <- metric("schema_snapshot", length(schema), notes = as.list(schema))

  prev <- dbGetQuery(con, "
    SELECT notes::text AS notes FROM pipeline_observability
    WHERE pipeline_name = $1 AND table_name = $2 AND stage = $3
      AND metric_name = 'schema_snapshot'
    ORDER BY run_timestamp DESC LIMIT 1",
    params = list(pipeline, table_name, stage))
  if (nrow(prev) == 0) return(snap)           # first run: nothing to compare

  old   <- unlist(fromJSON(prev$notes[1]))
  added <- setdiff(names(schema), names(old))
  gone  <- setdiff(names(old), names(schema))
  both  <- intersect(names(schema), names(old))
  typed <- both[schema[both] != old[both]]
  n     <- length(added) + length(gone) + length(typed)

  bind_rows(snap, metric("schema_changes", n, baseline = 0,
                         status = if (n > 0) "warn" else "ok",
                         notes = if (n > 0) list(added = added, removed = gone,
                                                 type_changed = typed)))
}

# Profile -> baselines -> grade -> schema, in one call
run_profile_checks <- function(con, profile, pipeline, table_name, stage, cfg) {
  base <- get_baselines(con, pipeline, table_name, stage, cfg$n_baseline)
  bind_rows(
    grade_against_baseline(profile_to_metrics(profile), base, cfg),
    check_schema_snapshot(con, pipeline, table_name, stage, profile$schema)
  )
}
