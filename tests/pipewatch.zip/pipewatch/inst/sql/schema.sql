CREATE TABLE IF NOT EXISTS pipeline_observability (
  id             bigserial PRIMARY KEY,
  run_id         uuid        NOT NULL,
  pipeline_name  text        NOT NULL,
  run_timestamp  timestamptz NOT NULL DEFAULT now(),
  run_by         text,
  stage          text        NOT NULL CHECK (stage IN ('input','output','ops')),
  table_name     text,
  metric_name    text        NOT NULL,
  metric_value   numeric,
  baseline_value numeric,
  status         text        NOT NULL CHECK (status IN ('ok','warn','fail')),
  notes          jsonb
);

CREATE INDEX IF NOT EXISTS idx_obs_history
  ON pipeline_observability (pipeline_name, table_name, stage, metric_name, run_timestamp DESC);

CREATE INDEX IF NOT EXISTS idx_obs_run
  ON pipeline_observability (run_id);

CREATE OR REPLACE VIEW v_pipeline_run_summary AS
SELECT run_id,
       pipeline_name,
       min(run_timestamp) AS run_timestamp,
       max(run_by)        AS run_by,
       CASE WHEN bool_or(status = 'fail') THEN 'fail'
            WHEN bool_or(status = 'warn') THEN 'warn'
            ELSE 'ok' END AS run_status,
       count(*) FILTER (WHERE status = 'fail') AS n_fail,
       count(*) FILTER (WHERE status = 'warn') AS n_warn
FROM pipeline_observability
GROUP BY run_id, pipeline_name;

CREATE OR REPLACE VIEW v_pipeline_latest AS
SELECT DISTINCT ON (pipeline_name) *
FROM v_pipeline_run_summary
ORDER BY pipeline_name, run_timestamp DESC;

CREATE OR REPLACE VIEW v_failed_checks_7d AS
SELECT run_timestamp, pipeline_name, run_by, stage, table_name,
       metric_name, metric_value, baseline_value, notes
FROM pipeline_observability
WHERE status = 'fail' AND run_timestamp > now() - interval '7 days'
ORDER BY run_timestamp DESC;
