# These tests need no database.
cfg <- pipewatch:::default_config()

mk <- function(name, value, baseline) {
  m    <- tibble::tibble(metric_name = name, metric_value = value)
  base <- tibble::tibble(metric_name = name, baseline_value = baseline)
  pipewatch:::grade_against_baseline(m, base, cfg)$status
}

test_that("row count thresholds", {
  expect_equal(mk("row_count", 200000, 200000), "ok")
  expect_equal(mk("row_count", 130000, 200000), "warn")   # -35%
  expect_equal(mk("row_count", 100000, 200000), "fail")   # -50%, the incident
})

test_that("no baseline never fails (first run)", {
  m <- tibble::tibble(metric_name = "row_count", metric_value = 5)
  base <- tibble::tibble(metric_name = character(), baseline_value = numeric())
  expect_equal(pipewatch:::grade_against_baseline(m, base, cfg)$status, "ok")
})

test_that("duplicates and rules fail on any violation", {
  expect_equal(mk("duplicate_keys", 1, 0), "fail")
  expect_equal(mk("rule_amount_non_negative", 3, 0), "fail")
  expect_equal(mk("duplicate_keys", 0, 0), "ok")
})

test_that("null rate uses absolute points", {
  expect_equal(mk("null_rate_x", 0.12, 0.01), "fail")
  expect_equal(mk("null_rate_x", 0.07, 0.01), "warn")
  expect_equal(mk("null_rate_x", 0.02, 0.01), "ok")
})

test_that("freshness must advance", {
  expect_equal(mk("newest_ts_epoch", 1000, 1000), "fail")
  expect_equal(mk("newest_ts_epoch", 2000, 1000), "ok")
})

test_that("reconciliation", {
  expect_equal(pipewatch:::check_reconciliation(100, 100)$status, "ok")
  expect_equal(pipewatch:::check_reconciliation(100, 90)$status, "fail")
})
