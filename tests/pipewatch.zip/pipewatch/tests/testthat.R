library(testthat)
library(pipewatch)
test_check("pipewatch")
