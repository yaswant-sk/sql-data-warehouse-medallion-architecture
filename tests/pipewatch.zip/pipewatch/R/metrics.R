# One row in the shape of the pipeline_observability table
to_json <- function(x) {
  if (is.null(x)) NA_character_ else as.character(toJSON(x, auto_unbox = TRUE, null = "null"))
}

metric <- function(name, value, baseline = NA_real_, status = "ok", notes = NULL) {
  tibble(metric_name = name,
         metric_value = as.numeric(value),
         baseline_value = as.numeric(baseline),
         status = status,
         notes = to_json(notes))
}

# Pillar 5 (lineage, phase 1): which sources fed which target
lineage_metric <- function(sources, target) {
  metric("lineage", NA_real_, notes = list(sources = sources, target = target))
}

# Pillar 2 (volume): does a total in the source equal the total in the target?
check_reconciliation <- function(source_value, target_value,
                                 name = "reconciliation_diff", tol = 0.01) {
  diff <- target_value - source_value
  metric(name, diff, baseline = 0, status = if (abs(diff) <= tol) "ok" else "fail")
}

# Compare one metric (e.g. "sum_amount") between input and output metrics of this run
reconcile_metric <- function(m_in, m_out, name, tol = 0.01) {
  get <- function(m) m$metric_value[m$metric_name == name]
  a <- get(m_in); b <- get(m_out)
  if (length(a) != 1 || length(b) != 1)
    stop("Cannot reconcile '", name, "': metric missing. Did you pass numeric_cols?", call. = FALSE)
  check_reconciliation(a, b, paste0(name, "_reconciliation_diff"), tol)
}
