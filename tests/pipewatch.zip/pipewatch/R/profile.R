# Profile a table (or aliased subquery) inside Postgres with ONE aggregate query.
# Millions of rows never leave the database.
#
# from_sql:     "raw.orders" or "(SELECT ...) t"
# key:          ONE column that should be unique
# ts_col:       "last updated" timestamp column
# numeric_cols: columns to track mean and sum for
# rules:        named SQL conditions that must be TRUE, e.g. c(amount_ok = "amount >= 0")
profile_sql <- function(con, from_sql, key, ts_col, numeric_cols = NULL, rules = NULL) {
  q <- function(x) as.character(dbQuoteIdentifier(con, x))

  # Zero-row query gives column names and types without reading data
  empty  <- dbGetQuery(con, paste("SELECT * FROM", from_sql, "LIMIT 0"))
  cols   <- names(empty)
  schema <- vapply(empty, function(x) class(x)[1], character(1))

  sel <- c(
    "count(*)::float8 AS row_count",
    sprintf("count(DISTINCT %s)::float8 AS distinct_keys", q(key)),
    sprintf("extract(epoch FROM max(%s))::float8 AS newest_ts_epoch", q(ts_col)),
    sprintf("avg((%s IS NULL)::int)::float8 AS %s", q(cols), q(paste0("null_rate_", cols)))
  )
  if (length(numeric_cols)) sel <- c(sel,
    sprintf("avg(%s)::float8 AS %s", q(numeric_cols), q(paste0("mean_", numeric_cols))),
    sprintf("sum(%s)::float8 AS %s", q(numeric_cols), q(paste0("sum_", numeric_cols))))
  if (length(rules)) sel <- c(sel,
    sprintf("count(*) FILTER (WHERE NOT coalesce((%s), false))::float8 AS %s",
            rules, q(paste0("rule_", names(rules)))))

  res <- dbGetQuery(con, paste("SELECT", paste(sel, collapse = ", "), "FROM", from_sql))
  list(values = unlist(res[1, ]), schema = schema)
}

# Raw profile -> metric rows (adds duplicates and data age)
profile_to_metrics <- function(p) {
  v <- p$values
  bind_rows(
    tibble(metric_name = names(v), metric_value = unname(v)),
    tibble(metric_name = "duplicate_keys",
           metric_value = v[["row_count"]] - v[["distinct_keys"]]),
    tibble(metric_name = "freshness_hours",
           metric_value = (as.numeric(Sys.time()) - v[["newest_ts_epoch"]]) / 3600)
  ) %>% filter(metric_name != "distinct_keys")
}
