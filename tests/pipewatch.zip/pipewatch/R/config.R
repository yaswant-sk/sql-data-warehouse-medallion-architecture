# Package-level state: current run context and configuration
.pw <- new.env(parent = emptyenv())

default_config <- function() {
  list(
    warn_change   = 0.30,  # relative change in counts/means/sums that warns
    fail_change   = 0.50,  # ... and fails
    null_warn     = 0.05,  # rise in null rate (absolute points) that warns
    null_fail     = 0.10,  # ... and fails
    max_age_hours = 24,    # data older than this fails the freshness check
    n_baseline    = 10,    # median of the last n runs is the baseline
    learning_runs = 3      # runs with fewer prior runs are logged but never block
  )
}

pw_cfg <- function() {
  if (is.null(.pw$config)) .pw$config <- default_config()
  .pw$config
}

#' Change settings for this R session, e.g. pw_config(max_age_hours = 48)
#' Call pw_config() with no arguments to see the current values.
pw_config <- function(...) {
  cfg <- pw_cfg()
  args <- list(...)
  bad <- setdiff(names(args), names(cfg))
  if (length(bad)) stop("Unknown setting(s): ", paste(bad, collapse = ", "), call. = FALSE)
  cfg[names(args)] <- args
  .pw$config <- cfg
  invisible(cfg)
}

current_ctx <- function() {
  if (is.null(.pw$ctx))
    stop("pw_source() and pw_write() must be called inside pw_run().", call. = FALSE)
  .pw$ctx
}

# "schema.table" -> DBI identifier
as_id <- function(table) {
  parts <- strsplit(table, ".", fixed = TRUE)[[1]]
  if (length(parts) == 2) Id(schema = parts[1], table = parts[2]) else Id(table = parts)
}
