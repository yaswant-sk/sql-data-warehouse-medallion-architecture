#' Send an alert. Always prints to the console. Also posts to Slack if the
#' PIPEWATCH_SLACK_WEBHOOK environment variable is set (needs the httr2 package).
#' For email or anything else, set options(pipewatch.alert_fn = function(msg, ctx) ...).
pw_notify <- function(ctx, level, title, details = "") {
  msg <- sprintf("[%s] %s\npipeline: %s | run by: %s | run_id: %s\n%s",
                 toupper(level), title, ctx$pipeline, ctx$run_by, ctx$run_id, details)
  message(msg)

  hook <- getOption("pipewatch.alert_fn")
  if (is.function(hook)) try(hook(msg, ctx), silent = TRUE)

  url <- Sys.getenv("PIPEWATCH_SLACK_WEBHOOK")
  if (nzchar(url) && requireNamespace("httr2", quietly = TRUE)) {
    try(httr2::req_perform(httr2::req_body_json(httr2::request(url), list(text = msg))),
        silent = TRUE)
  }
  invisible(msg)
}
