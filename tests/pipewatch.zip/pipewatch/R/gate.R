# Decide what to do with graded metrics:
#  - learning mode: too few earlier runs, so log but never block
#  - override:      person re-ran with override = TRUE; fails are logged as warn
#                   (so the baseline can move) and tagged with who overrode
#  - block:         any fail otherwise
decide_gate <- function(ctx, m, table_name, stage) {
  cfg      <- pw_cfg()
  prior    <- count_prior_runs(ctx$con, ctx$pipeline, table_name, stage)
  learning <- prior < cfg$learning_runs
  fails    <- m$metric_name[m$status == "fail"]

  if (length(fails) > 0 && ctx$override) {
    is_fail <- m$status == "fail"
    m$status[is_fail] <- "warn"
    m$notes[is_fail]  <- to_json(list(override_by = ctx$run_by))
  }

  warns <- m$metric_name[m$status == "warn"]
  if (length(warns)) message("pipewatch warnings (", table_name, "): ", paste(warns, collapse = ", "))
  if (learning) message(sprintf(
    "pipewatch: learning mode for %s (%d of %d baseline runs). Checks are logged but will not block.",
    table_name, prior, cfg$learning_runs))

  list(m = m, fails = fails, learning = learning,
       block = length(fails) > 0 && !ctx$override && !learning)
}

block_message <- function(table_name, stage, fails) {
  sprintf("BLOCKED: %s checks failed for %s (%s). %s To override a legitimate change, re-run with pw_run(..., override = TRUE).",
          stage, table_name, paste(fails, collapse = ", "),
          if (stage == "input") "Processing did not start." else "The write was rolled back.")
}
