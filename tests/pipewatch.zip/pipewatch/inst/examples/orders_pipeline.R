# What a developer's script looks like with pipewatch.
# The only additions: library(pipewatch), pw_run(), pw_source(), pw_write().
library(DBI)
library(pipewatch)

con <- dbConnect(RPostgres::Postgres(), dbname = "mydb")   # your usual connection

# One-time setup (safe to repeat): creates the log table and dashboard views
# pw_install_schema(con)

pw_run("orders_pipeline", con, {

  # 1. Declare and check the source BEFORE using it
  pw_source("raw.orders", key = "order_id", ts_col = "updated_at",
            numeric_cols = "amount",
            rules = c(amount_non_negative = "amount >= 0"))

  # 2. Your existing code, unchanged
  df <- dbGetQuery(con, "SELECT * FROM raw.orders")
  df_result <- df[df$amount > 0, ]          # ... whatever your processing does

  # 3. Write through pw_write() instead of dbWriteTable()
  pw_write(df_result, "mart.orders", key = "order_id", ts_col = "updated_at",
           numeric_cols = "amount",
           reconcile = list(source = "raw.orders", metrics = "sum_amount"))
})
